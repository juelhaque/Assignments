<?php $__env->startSection('content'); ?>

    <div class="container">
        <div>
            <a class="btn btn-dark mt-2" href="<?php echo e(route('products.index')); ?>">Back</a>
        </div>
        <div class="row justify-content-center">
            <div class="col-sm-8 my-4">
                <div class="card p-4">
                    <h3>Name : <?php echo e($product->name); ?></h3>
                    <p>Description : <?php echo e($product->description); ?></p>
                    <p>Price : <?php echo e($product->price); ?></p>
                    <p>Image :</p>
                    <img src="<?php echo e(asset('product/' . $product->image)); ?>" alt="image" class="rounded" width="100%">
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\To-Do_CRUD_Module\resources\views/product/show.blade.php ENDPATH**/ ?>