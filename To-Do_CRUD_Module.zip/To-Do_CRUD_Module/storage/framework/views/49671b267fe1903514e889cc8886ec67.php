<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="text-end">
            <a class="btn btn-primary mt-3" href="<?php echo e(route('products.create')); ?>">New Product</a>
        </div>

        <?php if(session('message')): ?>
            <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                <strong>Successful!</strong> <?php echo e(session('message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>SL#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->description); ?></td>
                            <td><?php echo e($product->price); ?></td>
                            <td>
                                <img src="<?php echo e(asset('product/' . $product->image)); ?>" alt="image" class="rounded-circle" height="30" width="30">
                            </td>
                            <td>
                                <a href="<?php echo e(route('products.show', [$product->id])); ?>" class="btn btn-sm btn-primary">Show</a>
                                <a href="<?php echo e(route('products.edit', [$product->id])); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <form class="d-inline" action="<?php echo e(route('products.destroy', [$product->id])); ?>" method="post">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button onclick="alert('Are you sure?')" class="btn btn-sm btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($products->links()); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\To-Do_CRUD_Module\resources\views/product/index.blade.php ENDPATH**/ ?>