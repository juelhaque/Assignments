<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(){
        $products = Product::latest()->paginate(6);
        return view('product.index', ['products' => $products]);
    }


    public function create(){
        return view('product.create');
    }


    public function store(Request $request){
        $request->validate([
                'name'=>['required', 'min:3', 'max:50'],
                'description'=>['required', 'min:3', 'max:150'],
                'price'=>['required'],
                'image'=>['required'],
            ]);

        $imageName = time().'.'.$request->image->extension();
        $request->image->move(public_path('product'), $imageName);

        $product = new Product;
        $product->name = $request->name;
        $product->description = $request->description;
        $product->price = $request->price;
        $product->image = $imageName;
        $product->save();

        return redirect()->route('products.index')->withMessage('Product Created !');
    }


    public function show($id){
        $product = Product::where('id', $id)->first();
        return view('product.show', ['product' => $product]);
    }


    public function edit($id){
        $product = Product::where('id', $id)->first();
        return view('product.edit', ['product' => $product]);
    }


    public function update(Request $request, $id){
        $request->validate([
            'name'=>['required', 'min:3', 'max:50'],
            'description'=>['required', 'min:3', 'max:150'],
            'price'=>['required'],
            'image'=>['nullable'],
        ]);

        $product = Product::where('id', $id)->first();

        if (isset($request->image)) {
            $imageName = time().'.'.$request->image->extension();
            $request->image->move(public_path('product'), $imageName);
            $product->image = $imageName;
        }

        $product->name = $request->name;
        $product->description = $request->description;
        $product->price = $request->price;
        $product->save();

        return redirect()->route('products.index')->withMessage('Product Updated !');
    }


    public function destroy($id){
        $product = Product::where('id', $id)->first();
        $product->delete();

        return redirect()->route('products.index')->withMessage('Product Deleted !');
    }

}
