@extends('layouts.app')

@section('content')

    <div class="container">
        <div>
            <a class="btn btn-dark mt-2" href="{{ route('products.index') }}">Back</a>
        </div>
        <div class="row justify-content-center">
            <div class="col-sm-8 my-4">
                <div class="card p-4">
                    <h3>Name : {{ $product->name }}</h3>
                    <p>Description : {{ $product->description }}</p>
                    <p>Price : {{ $product->price }}</p>
                    <p>Image :</p>
                    <img src="{{ asset('product/' . $product->image) }}" alt="image" class="rounded" width="100%">
                </div>
            </div>
        </div>
    </div>

@endsection
