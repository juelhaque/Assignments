@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="text-end">
            <a class="btn btn-primary mt-3" href="{{ route('products.create') }}">New Product</a>
        </div>

        @if(session('message'))
            <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                <strong>Successful!</strong> {{session('message')}}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>SL#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($products as $product)
                        <tr>
                            <td>{{ $loop->index + 1 }}</td>
                            <td>{{ $product->name }}</td>
                            <td>{{ $product->description }}</td>
                            <td>{{ $product->price }}</td>
                            <td>
                                <img src="{{ asset('product/' . $product->image) }}" alt="image" class="rounded-circle" height="30" width="30">
                            </td>
                            <td>
                                <a href="{{ route('products.show', [$product->id])}}" class="btn btn-sm btn-primary">Show</a>
                                <a href="{{ route('products.edit', [$product->id])}}" class="btn btn-sm btn-warning">Edit</a>
                                <form class="d-inline" action="{{route('products.destroy', [$product->id])}}" method="post">
                                    @method('delete')
                                    @csrf
                                    <button onclick="alert('Are you sure?')" class="btn btn-sm btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            {{ $products->links() }}

        </div>
    </div>
@endsection

