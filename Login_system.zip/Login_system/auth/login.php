<?php
include_once 'guest.php';
include_once 'app/User.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $user = new User;
    $user->email = $_POST['email'];
    $user->password = $_POST['password'];

    if($user->login()){
        $_SESSION['user_id'] = $user->id;
        header('location: dashboard.php');
    }else{
        echo 'Unable to Login User';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div class="row justify-content-center">
        <div class="col-sm-4 mt-4 pt-4">
            <div class="container mt-3">
                <h2 class="text-center">Login form</h2>
                <form action="login.php" method="">
                    <div class="mb-3 mt-3">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                    </div>
                    <div class="mb-3">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
                    </div>
                    <!-- <div class="form-check mb-3">
                        <label class="form-check-label">
                            <input class="form-check-input" type="checkbox" name="remember"> Remember me
                        </label>
                        <a href="#!" class="d-end justify-content-end">Forgot password?</a>
                    </div> -->
                    <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
                    <div class="text-center text-lg-start mt-1 pt-2">
                        <button type="button" class="btn btn-primary px-4">Login</button>
                        <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account? <a href="./register.php" class="link-danger">Register</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>

</html>