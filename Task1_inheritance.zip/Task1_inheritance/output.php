<?php
include_once 'Geometric.php';

class output extends geometric{
    
}

$rectangle = new output();
$rectangle->length = 10;
$rectangle->width = 5;
$rectangle->areaOfRectangle();


$circle = new output();
$circle->redius = 10;
$circle->pi = 3.1416;
$circle->areaOfCircle();


$triangle = new output();
$triangle->height = 10;
$triangle->width = 6;
$triangle->areaOfTriangle();


$square = new output();
$square->side = 10;
$square->areaOfSquare();

?>