<?php

class geometric{
    
    public $area, $length, $height, $width, $pi, $redius, $side;

    public function areaOfRectangle(){
        echo "Length = ". $this->length. '<br>';
        echo "Width = ". $this->width. '<br>';
        echo "Area of Rectangle = ". $this->area = $this->length * $this->width.'<br><br>';
        return $this->area;
    }

    public function areaOfCircle(){
        echo "Redius = ". $this->redius. '<br>';
        echo "Pi = ". $this->pi. '<br>';
        echo "Area of Circle = ". $this->area = $this->pi * $this->redius * $this->redius.'<br><br>';
        return $this->area;
    }

    public function areaOfTriangle(){
        echo "height = ". $this->height. '<br>';
        echo "Width = ". $this->width. '<br>';
        echo "Area of Triangle = ". $this->area = ($this->height * $this->width)/2 .'<br><br>';
        return $this->area;
    }

    public function areaOfSquare(){
        echo "Side = ". $this->side. '<br>';
        echo "Area of Square = ". $this->area = $this->side * $this->side;
        return $this->area;
    }
}



?>